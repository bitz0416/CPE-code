//https://www.delftstack.com/zh-tw/howto/cpp/how-to-iterate-over-map-in-cpp/
// g++ std-map3.cpp -o a.out -std=s
//�Q�n�bDEV C++�B��C++11�{���X�G
//�u��->�sĶ���ﶵ->�@��
//�I�s�sĶ���[�J���O "-std=c++11" or "-std=c++0x"
#include <iostream>
#include <string>
#include <map>
using namespace std;
int main() {
    map<int, string> tempMap = {
		{1, "Apple",},
      	{2, "Banana",},
        {3, "Mango",},
        {4, "Raspberry",},
        {5, "Blackberry",},
        {6, "Cocoa",}
	};

    auto iter = tempMap.begin();
    while (iter != tempMap.end()) {
        cout << "[" << iter->first << ","
                    << iter->second << "]\n";
        ++iter;
    }
    cout << endl;
    return 0;
}
