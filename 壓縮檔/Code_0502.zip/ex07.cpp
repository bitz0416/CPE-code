#include <iostream>
using namespace std;
int main()
{
	int a[3];
	
 	int *a;
	a = new int[3];
	delete []a; 
	
  	return 0;   
}
