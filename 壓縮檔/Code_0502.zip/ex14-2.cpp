#include <iostream>
#include <cctype>
using namespace std;
int main(){
	for (char c : "Hello, World!")
		if (isalpha(c))
			cout << c;
	cout << endl;
	return 0;
}
