#include <iostream>
#include <cstring>
using namespace std;
int main(){
	int n;
	char str[3][8];
	n=0;
	while (cin.getline(str[n], 8))
	{
		cout << strlen(str[n]) << endl;		
		n++;
	}
	return 0;
}
