#include <iostream>
#include <sstream>
using namespace std;
int main()
{
	stringstream SS;
	string Str;
	
	int num;
	num = 100;
	SS << num;
	SS >> Str;
  	cout << Str << endl;
	return 0;   
}
