#include <iostream>
#include <cstdlib>
using namespace std;
int main(){
	for(char i='a';i<'z';i++)
		cout << i << " ";
	cout << endl;

	for(char i='a';i<'z';i++)
		cout << i-32 << " "; 
	cout << endl;		

	for(char i='a';i<'z';i++)
		cout << (char)(i-32) << " "; 
	cout << endl;

	char a='2';
	int b = a-'0'; 
	cout << a*10 << endl;
	cout << b*10 << endl;
	return 0;
}
