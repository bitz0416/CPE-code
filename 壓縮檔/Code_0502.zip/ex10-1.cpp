#include<iostream>
#include<vector>
using namespace std;
int main()
{
	//array
	int v1[] = {1,2,3,4,5};
	for(int i=0;i<5; i++)
	{
		cout << v1[i] << endl;		
	}
	//vector	
	vector<double> v = {1,2,3,4,5};
	for(int i=0;i<v.size();i++)
	{
		cout << v[i] << endl;		
	}
    //vector
    vector<double>::iterator i;
	for(i = v.begin(); i != v.end(); i++)
	{
		cout << *i << endl;		
	}
	return 0;
}
