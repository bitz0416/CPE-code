#include <iostream>
#include <Algorithm>
//#include <vector>
using namespace std;
int main()
{
	//vector<int> b={4,5,6,2,10}; 
	//cout << b.at(2) << endl;
	//cout << b[2]<< endl;
		
	int a[5]={4,5,6,2,10};
	sort(a,a+5);
	for(int i=0;i<5;i++)
		cout << a[i] << " ";
	cout << endl;	
  	return 0;   
}
