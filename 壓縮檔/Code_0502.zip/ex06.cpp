#include <iostream>
using namespace std;
int main()
{
    double s =3.14159;
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);    
    cout.precision(4);
	cout << s << endl; 
  	return 0;   
}
