#include <iostream>
using namespace std;
int main()
{
 	int b[2][3];
 	
	int **a;
	a = new int*[2];
	a[0]=new int[3];
	a[1]=new int[3];
	
	delete []a[0];
	delete []a[1];
	delete []a; 
  	return 0;   
}
