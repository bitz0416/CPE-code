#include <iostream>
#include <cmath>
using namespace std;
int main(){
	double a,b;
	a=3, b=4;
	cout << pow(a,b) << endl;
	cout << sqrt(a) << endl;
	return 0;
}
