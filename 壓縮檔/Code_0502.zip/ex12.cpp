#include <iostream>
#include <cstdlib>
using namespace std;
int main(){
	char a1[] = "1000"; //�r���}�C 
	string a2 = "1000"; //�r�� 
	int b1,b2;
	
	char* end;
	b1 = strtol(a1, NULL, 10); //strtol() function when decimal base 
	cout << b1 <<endl;
	
	b2 = strtol(a2.c_str(), NULL, 10); //strtol() function when decimal base 
	cout << b2 <<endl;

	cout << b1*b1 << endl;
	cout << b1*b2 << endl;
	cout << b2*b2 << endl;
    return 0;
}
