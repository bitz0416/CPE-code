#include <iostream>
#include <cctype>
using namespace std;
int main(){
	
	for (char c : "Hello, World!")
		cout << char(tolower(c));
	cout << endl;
	
	cout << (char)tolower('C') << endl;
	
	return 0;
}
