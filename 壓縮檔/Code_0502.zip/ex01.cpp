#include<iostream>
#include <iomanip>
using namespace std;
int main()
{
	int n;
	cin >> n;
	while(n--){
		cout << "ok" << endl; 
	}
  	return 0;   
}
