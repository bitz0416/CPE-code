// g++ std-map3.cpp -o a.out -std=s
//�Q�n�bDEV C++�B��C++11�{���X�G
//�u��->�sĶ���ﶵ->�@��
//�I�s�sĶ���[�J���O "-std=c++11" or "-std=c++0x"
#include <iostream>
#include <string>
#include <map>
using namespace std;
int main() {
    map<string, int> map = {
        {"Tom", 1},
        {"Jack", 2},
        {"Ann", 4}
    };
    for (const auto& n : map) {
        cout << "key: " << n.first << " value: " << n.second << "\n";
    }

    map["Tiffany"] = 5;
    map["John"] = 3;

    cout << map["John"] << "\n";
    cout << map["Tiffany"] << "\n";

    for (const auto& n : map) {
       	cout << "key: " << n.first << " value: " << n.second << "\n";
    }
    return 0;
}
